package parking;

public class ParkingSpot {
    private int spotId;
    private String spotType;
    private boolean isOccupied;
    public ParkingSpot(int spotId, String spotType) {
        this.spotId = spotId;
        this.spotType = spotType;
        this.isOccupied = false;
    }
    public int getSpotId() { return spotId; }
    public String getSpotType() { return spotType; }
    public boolean isOccupied() { return isOccupied; }
    public void setOccupied(boolean occupied) { isOccupied = occupied; }
}
