package parking;

import vehicle.Vehicle;

import java.util.Date;

public class ParkingRecord {
    private Vehicle vehicle;
    private ParkingSpot parkingSpot;
    private Date parkedTime;
    private Date exitTime;
    
    public ParkingRecord(Vehicle vehicle, ParkingSpot spot) {
        this.vehicle = vehicle;
        this.parkingSpot = spot;
        this.parkedTime = new Date();
    }

    public void setExitTime() { exitTime = new Date(); }
    public Vehicle getVehicle() { return vehicle; }
    public ParkingSpot getParkingSpot() { return parkingSpot; }
    public Date getParkedTime() { return parkedTime; }
    public Date getExitTime() { return exitTime; }
}
