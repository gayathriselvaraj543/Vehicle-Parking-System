package parking;

public class ParkingFeeCalculator {
    public double calculateFee(ParkingRecord record) {
        long diff = record.getExitTime().getTime() - record.getParkedTime().getTime();
        return diff / (1000 * 60 * 60) * 10; 
    }
}
