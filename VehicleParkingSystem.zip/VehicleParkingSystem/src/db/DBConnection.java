    package db;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;

	public class DBConnection {
	    private static final String URL = "jdbc:mysql://localhost:3306/VehicleParkingSystem";
	    private static final String USER = "root";
	    private static final String PASSWORD = "gaya@#1234@#";

	    public static Connection getConnection() {
	        Connection con = null;
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            con = DriverManager.getConnection(URL, USER, PASSWORD);
	            System.out.println("Database connection established successfully.");
	        } catch (ClassNotFoundException e) {
	            System.err.println("MySQL JDBC Driver not found. Add the JDBC library to the project.");
	        } catch (SQLException e) {
	            System.err.println("Failed to connect to the database: " + e.getMessage());
	        }
	        return con;
	    }
	    public static void main(String[] args)
	    {
	    	Connection con =DBConnection.getConnection();
	    }
	}


