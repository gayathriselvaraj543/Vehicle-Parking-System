package db;

import parking.ParkingRecord;
import vehicle.Vehicle;

import java.sql.*;

public class ParkingDBHandler {
    private DBConnection dbConnection = new DBConnection();
    
    public void saveParkingRecord(ParkingRecord record) {
        try (Connection connection = DBConnection.getConnection()) {
            String query = "INSERT INTO parking_records (vehicle_id, spot_id, parked_time) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setInt(1, record.getVehicle().getLicensePlate().hashCode());
                stmt.setInt(2, record.getParkingSpot().getSpotId());
                stmt.setTimestamp(3, new Timestamp(record.getParkedTime().getTime()));
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void saveVehicle(Vehicle vehicle) {
    	
        String query = "INSERT INTO vehicles (license_plate, vehicle_type, owner_name, owner_contact) VALUES (?, ?, ?, ?)";
        
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, vehicle.getLicensePlate());
            stmt.setString(2, vehicle.getVehicleType());
            stmt.setString(3, vehicle.getOwnerName());
            stmt.setString(4, vehicle.getOwnerContact());
            stmt.executeUpdate();
            System.out.println("Vehicle details saved successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Failed to save vehicle details.");
        }
    }
}
