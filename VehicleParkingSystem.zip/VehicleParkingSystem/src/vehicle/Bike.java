package vehicle;

public class Bike extends Vehicle {

    public Bike() {
        setVehicleType("Bike");
    }

    @Override
    public String getVehicleCategory() {
        return "Bike";
    }
}
