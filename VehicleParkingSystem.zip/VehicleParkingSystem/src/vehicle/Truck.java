package vehicle;

public class Truck extends Vehicle {

    public Truck() {
        setVehicleType("Truck");
    }

    @Override
    public String getVehicleCategory() {
        return "Truck";
    }
}
