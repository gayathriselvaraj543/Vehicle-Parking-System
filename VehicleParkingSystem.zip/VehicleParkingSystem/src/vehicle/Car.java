package vehicle;

public class Car extends Vehicle {

    public Car() {
        setVehicleType("Car");
    }

    @Override
    public String getVehicleCategory() {
        return "Car";
    }
}
