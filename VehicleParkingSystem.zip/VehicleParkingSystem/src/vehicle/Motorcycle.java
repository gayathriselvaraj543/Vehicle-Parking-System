package vehicle;

public class Motorcycle extends Vehicle {

    public Motorcycle() {
        setVehicleType("Motorcycle");
    }

    @Override
    public String getVehicleCategory() {
        return "Motorcycle";
    }
}
