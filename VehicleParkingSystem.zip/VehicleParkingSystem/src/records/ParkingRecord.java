package records;

import java.time.LocalDateTime;

public class ParkingRecord {
    private int recordId;
    private String licensePlate;
    private int spotId;
    private LocalDateTime parkedTime;
    private LocalDateTime exitTime;
    private double fee;

    public ParkingRecord(int recordId, String licensePlate, int spotId, LocalDateTime parkedTime) {
        this.recordId = recordId;
        this.licensePlate = licensePlate;
        this.spotId = spotId;
        this.parkedTime = parkedTime;
    }

    public void setExitTime(LocalDateTime exitTime) {
        this.exitTime = exitTime;
    }

    public void setFee(double fee) {
        this.fee = fee;
    }
}
