package fees;

public class ParkingFees {
    private String vehicleType;
    private String spotType;
    private double hourlyRate;

    public ParkingFees(String vehicleType, String spotType, double hourlyRate) {
        this.vehicleType = vehicleType;
        this.spotType = spotType;
        this.hourlyRate = hourlyRate;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }
}
