package main;

import vehicle.Vehicle;
import vehicle.Car;
import vehicle.Bike;
import vehicle.Motorcycle;
import vehicle.Truck;
import parking.ParkingSpot;
import parking.ParkingRecord;
import parking.ParkingFeeCalculator;
import db.ParkingDBHandler;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ParkingSpot spot = new ParkingSpot(1, "Standard");  
        ParkingFeeCalculator feeCalculator = new ParkingFeeCalculator();
        ParkingDBHandler dbHandler = new ParkingDBHandler();

        Vehicle parkedVehicle = null;
        Vehicle[] vehicles = new Vehicle[4];  
        for (int i = 0; i < vehicles.length; i++) {
            System.out.println("Enter details for Vehicle " + (i + 1));
            System.out.println("Choose Vehicle Type: 1. Car  2. Bike  3. Motorcycle  4. Truck");
            int vehicleChoice = scanner.nextInt();
            scanner.nextLine(); 

            Vehicle vehicle = null;
            if (vehicleChoice == 1) {
                vehicle = new Car();
            } else if (vehicleChoice == 2) {
                vehicle = new Bike();
            } else if (vehicleChoice == 3) {
                vehicle = new Motorcycle();
            } else if (vehicleChoice == 4) {
                vehicle = new Truck();
            } else {
                System.out.println("Invalid choice! Please enter a valid vehicle type.");
                i--;  
                continue;
            }
            System.out.print("Enter License Plate: ");
            vehicle.setLicensePlate(scanner.nextLine());
            System.out.print("Enter Owner Name: ");
            vehicle.setOwnerContact(scanner.nextLine());
            System.out.print("Enter Owner Contact: ");
            vehicle.setOwnerContact(scanner.nextLine());

            dbHandler.saveVehicle(vehicle);

            vehicles[i] = vehicle;
            System.out.println("Vehicle " + (i + 1) + " details saved.\n");
        }

        while (true) {
            System.out.println("\n1. Park Vehicle\n2. Retrieve Vehicle\n3. Calculate Fee\n4. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:  
                    System.out.println("Choose Vehicle to Park:");
                    for (int i = 0; i < vehicles.length; i++) {
                        System.out.println((i + 1) + ". " + vehicles[i].getLicensePlate());
                    }

                    int vehicleChoice = scanner.nextInt();
                    scanner.nextLine(); 

                    if (vehicleChoice >= 1 && vehicleChoice <= vehicles.length) {
                        Vehicle vehicle = vehicles[vehicleChoice - 1];

                        if (!spot.isOccupied()) {
                            spot.setOccupied(true);
                            parkedVehicle = vehicle;  
                            ParkingRecord record = new ParkingRecord(vehicle, spot);
                            dbHandler.saveParkingRecord(record);
                            System.out.println("Vehicle " + vehicle.getLicensePlate() + " parked.");
                        } else {
                            System.out.println("No available spots.");
                        }
                    } else {
                        System.out.println("Invalid choice. Please try again.");
                    }
                    break;

                case 2:  
                    if (parkedVehicle != null && spot.isOccupied()) {
                        spot.setOccupied(false);
                        System.out.println("Vehicle with License Plate " + parkedVehicle.getLicensePlate() + " retrieved.");
                        parkedVehicle = null; 
                    } else {
                        System.out.println("No vehicle to retrieve.");
                    }
                    break;

                case 3: 
                    if (parkedVehicle == null || !spot.isOccupied()) {
                        System.out.println("No vehicle parked. Cannot calculate fee.");
                    } else {
                        System.out.println("Enter parked hours: ");
                        long hours = scanner.nextLong();
                        ParkingRecord parkingRecord = new ParkingRecord(parkedVehicle, spot);
                        double fee = feeCalculator.calculateFee(parkingRecord); 
                        System.out.println("Parking Fee: " + fee);
                    }
                    break;

                case 4:  
                    System.out.println("Exiting system.");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
