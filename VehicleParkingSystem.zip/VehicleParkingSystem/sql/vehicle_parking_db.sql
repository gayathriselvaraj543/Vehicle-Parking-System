CREATE DATABASE IF NOT EXISTS vehicle_parking;
USE vehicle_parking;

CREATE TABLE Vehicles (
    vehicle_id INT PRIMARY KEY AUTO_INCREMENT,
    license_plate VARCHAR(20),
    vehicle_type VARCHAR(50),
    owner_name VARCHAR(100),
    owner_contact VARCHAR(15)
);

CREATE TABLE ParkingSpots (
    spot_id INT PRIMARY KEY AUTO_INCREMENT,
    spot_type VARCHAR(50),
    is_occupied BOOLEAN DEFAULT FALSE,
    vehicle_id INT,
    FOREIGN KEY (vehicle_id) REFERENCES Vehicles(vehicle_id)
);

CREATE TABLE ParkingRecords (
    record_id INT PRIMARY KEY AUTO_INCREMENT,
    vehicle_id INT,
    spot_id INT,
    parked_time DATETIME,
    exit_time DATETIME,
    parking_fee DECIMAL(8, 2),
    FOREIGN KEY (vehicle_id) REFERENCES Vehicles(vehicle_id),
    FOREIGN KEY (spot_id) REFERENCES ParkingSpots(spot_id)
);

CREATE TABLE ParkingFees (
    vehicle_type VARCHAR(50),
    spot_type VARCHAR(50),
    hourly_rate DECIMAL(8, 2),
    PRIMARY KEY (vehicle_type, spot_type)
);
